import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

def get_forms(url, session=None):
    sess = session or requests
    try:
        response = sess.get(url, timeout=5)
        soup = BeautifulSoup(response.text, "lxml")
        forms = soup.find_all("form")
        return forms
    except Exception as e:
        print(f("[!] Error fetching {url}: {e}"))
        return []

def parse_form_details(form, base_url):
    details = {}
    action = form.attrs.get("action")
    method = form.attrs.get("method", "get").lower()
    inputs = []

    for input_tag in form.find_all("input"):
        input_type = input_tag.attrs.get("type", "text")
        input_name = input_tag.attrs.get("name")
        inputs.append({"type": input_type, "name": input_name})

    details["action"] = urljoin(base_url, action)
    details["method"] = method
    details["inputs"] = inputs
    return details
