import json
import requests
from pathlib import Path

def build_session():
    """
    Returns: (session, logged_in: bool)
    If auth.json exists, tries to log in and return an authenticated Session.
    Otherwise returns a plain Session (guest).
    """
    s = requests.Session()
    cfg_path = Path(__file__).resolve().parents[1] / "auth.json"

    if not cfg_path.exists():
        print("[i] auth.json not found; scanning as guest.")
        return s, False

    try:
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        login_url = cfg["login_url"]
        data = dict(cfg.get("extra_fields", {}))
        data[cfg["username_field"]] = cfg["username"]
        data[cfg["password_field"]] = cfg["password"]

        r = s.post(login_url, data=data, timeout=10, allow_redirects=True)
        print(f"[+] Login POST to {login_url} => {r.status_code}")
        # naive success check (for demo)
        logged_in = bool(s.cookies)
        if logged_in:
            print("[+] Logged in; session cookies present.")
        else:
            print("[!] Could not confirm login; continuing as guest.")
        return s, logged_in
    except Exception as e:
        print(f"[!] Login failed: {e}")
        return s, False
