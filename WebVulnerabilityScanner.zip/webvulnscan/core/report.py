import os
from xml.sax.saxutils import escape
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
import matplotlib.pyplot as plt
from collections import Counter

def generate_report(findings, output_dir):
    """
    Generate a PDF report and severity pie chart based on scanner findings.
    """
    pdf_path = os.path.join(output_dir, "vuln_report.pdf")
    chart_path = os.path.join(output_dir, "severity_pie.png")

    # ✅ Generate pie chart
    severities = [severity for _, severity, _ in findings]
    severity_counts = Counter(severities)

    if severity_counts:
        ordered_levels = ["Critical", "High", "Medium", "Low"]
        labels = [level for level in ordered_levels if level in severity_counts]
        sizes = [severity_counts[level] for level in labels]
        colors_map = {
            "Critical": "#ffd966",  # Yellow
            "High": "#ff944d",      # Orange
            "Medium": "#ff4d4d",    # Red
            "Low": "#a3d977"        # Green
        }
        colors = [colors_map[level] for level in labels]

        def autopct(p):
            count = int(round(p * sum(sizes) / 100.0))
            return f"{p:.1f}% ({count})"

        plt.figure(figsize=(5, 5))
        plt.pie(sizes, labels=labels, autopct=autopct, colors=colors, startangle=140)
        plt.title("Severity Breakdown")
        plt.axis("equal")
        plt.tight_layout()
        plt.savefig(chart_path)
        plt.close()
    else:
        chart_path = None

    # ✅ Generate PDF
    doc = SimpleDocTemplate(pdf_path, pagesize=A4)
    story = []
    styles = getSampleStyleSheet()

    story.append(Paragraph("Web Vulnerability Scan Report", styles["Title"]))
    story.append(Spacer(1, 0.25 * inch))

    if chart_path and os.path.exists(chart_path):
        story.append(Image(chart_path, width=4 * inch, height=4 * inch))
        story.append(Spacer(1, 0.25 * inch))

    if not findings:
        story.append(Paragraph("No vulnerabilities found.", styles["Normal"]))
    else:
        for vuln_type, severity, res in findings:
            para = f"""
                <b>Vulnerability:</b> {vuln_type}<br/>
                <b>Severity:</b> {severity}<br/>
                <b>URL:</b> {res['url']}<br/>
                <b>Payload:</b> {res['payload']}<br/>
                <b>Evidence:</b> {res['evidence']}<br/>
                <br/>
                <hr width="100%"/>
            """
            story.append(Paragraph(escape(para), styles["Normal"]))
            story.append(Spacer(1, 0.2 * inch))

    doc.build(story)
