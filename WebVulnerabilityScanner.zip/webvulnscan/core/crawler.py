import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse

def crawl(url, max_pages=10, session=None):
    visited = set()
    to_visit = [url]
    sess = session or requests  # works with Session or requests module

    while to_visit and len(visited) < max_pages:
        current_url = to_visit.pop(0)
        if current_url in visited:
            continue

        try:
            print(f"[+] Visiting: {current_url}")
            response = sess.get(current_url, timeout=5)
            visited.add(current_url)

            soup = BeautifulSoup(response.text, "lxml")
            for link in soup.find_all("a", href=True):
                new_url = urljoin(current_url, link["href"])
                if urlparse(new_url).netloc == urlparse(url).netloc:
                    if new_url not in visited and new_url not in to_visit:
                        to_visit.append(new_url)

        except Exception as e:
            print(f"[!] Error visiting {current_url}: {e}")

    return visited

if __name__ == "__main__":
    start_url = "http://testphp.vulnweb.com/"
    found_links = crawl(start_url, max_pages=20)
    print("\n=== Links Discovered ===")
    for link in found_links:
        print(link)
