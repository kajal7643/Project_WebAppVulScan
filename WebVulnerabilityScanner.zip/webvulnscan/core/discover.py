from pathlib import Path
from datetime import datetime

from crawler import crawl
from form_parser import get_forms, parse_form_details

TARGET = "http://testphp.vulnweb.com/"
MAX_PAGES = 30

def main():
    print(f"[+] Starting discovery on: {TARGET}")
    urls = crawl(TARGET, max_pages=MAX_PAGES)
    print(f"[+] Pages crawled: {len(urls)}")

    reports_dir = Path(__file__).resolve().parents[1] / "reports"
    reports_dir.mkdir(exist_ok=True)

    links_path = reports_dir / "crawled_links.txt"
    forms_path = reports_dir / "forms_report.txt"

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Save crawled links
    with links_path.open("w", encoding="utf-8") as lf:
        lf.write(f"Discovery run: {ts}\nTarget: {TARGET}\nTotal pages: {len(urls)}\n\n")
        for u in sorted(urls):
            lf.write(u + "\n")

    # Save forms discovered
    total_forms = 0
    with forms_path.open("w", encoding="utf-8") as ff:
        ff.write(f"Forms report\nRun: {ts}\nTarget: {TARGET}\n\n")
        for u in sorted(urls):
            forms = get_forms(u)
            if not forms:
                continue
            ff.write(f"URL: {u}\n")
            for i, form in enumerate(forms, start=1):
                details = parse_form_details(form, u)
                ff.write(f"  Form #{i}\n")
                ff.write(f"    Action: {details['action']}\n")
                ff.write(f"    Method: {details['method']}\n")
                ff.write(f"    Inputs:\n")
                for inp in details['inputs']:
                    ff.write(f"      - type={inp['type']} name={inp['name']}\n")
                total_forms += 1
            ff.write("\n")

    print(f"[+] Forms found: {total_forms}")
    print(f"[+] Saved: {links_path}")
    print(f"[+] Saved: {forms_path}")

if __name__ == "__main__":
    main()
