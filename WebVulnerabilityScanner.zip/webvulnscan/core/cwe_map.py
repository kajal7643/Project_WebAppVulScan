CWE_MAP = {
    "SQLi": "CWE-89: SQL Injection",
    "XSS": "CWE-79: Cross-Site Scripting",
    "CSRF": "CWE-352: Cross-Site Request Forgery",
    "Headers": "CWE-693: Protection Mechanism Failure"
}
