from core.report import generate_report
from pathlib import Path
from core.auth import build_session
from core.crawler import crawl
from core.form_parser import get_forms, parse_form_details
from detectors.xss_detector import test_xss
from detectors.sqli_detector import test_sqli
from detectors.csrf_detector import test_csrf
from detectors.headers_detector import test_headers
from core.cwe_map import CWE_MAP

def load_payloads(path):
    with open(path, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def main():
    TARGET = "http://testphp.vulnweb.com/"

    session, logged_in = build_session()
    urls = crawl(TARGET, max_pages=15, session=session)

    xss_payloads = load_payloads("payloads/xss.txt")
    sqli_payloads = load_payloads("payloads/sqli.txt")

    reports_dir = Path(__file__).resolve().parents[1] / "reports"
    reports_dir.mkdir(exist_ok=True)
    report_file = reports_dir / "vuln_report.txt"

    findings = []

    for u in urls:
        # ✅ Security Headers check
        try:
            r = session.get(u, timeout=5)
            header_results = test_headers(r)
            for res in header_results:
                findings.append(("Headers", "Medium", res))
        except Exception as e:
            print(f"[!] Header check error: {e}")

        # ✅ Form-based checks
        forms = get_forms(u, session=session)
        for form in forms:
            details = parse_form_details(form, u)

            # XSS
            xss_results = test_xss(u, details, xss_payloads, session=session)
            for res in xss_results:
                findings.append(("XSS", "High", res))

            # SQLi
            sqli_results = test_sqli(u, details, sqli_payloads, session=session)
            for res in sqli_results:
                findings.append(("SQLi", "Critical", res))

            # CSRF
            csrf_results = test_csrf(u, details)
            for res in csrf_results:
                findings.append(("CSRF", "Medium", res))

    # ✅ Write report
    with report_file.open("w", encoding="utf-8") as f:
        login_note = "Authenticated" if logged_in else "Guest"
        f.write(f"Scan Mode: {login_note}\n\n")
        for vuln_type, severity, res in findings:
            cwe = CWE_MAP.get(vuln_type, "N/A")
            f.write(f"[{vuln_type}] Severity: {severity} ({cwe})\n")
            f.write(f"URL: {res['url']}\n")
            f.write(f"Payload: {res['payload']}\n")
            f.write(f"Evidence: {res['evidence']}\n")
            f.write("-" * 50 + "\n")

    print(f"[+] Scan complete. Findings saved to {report_file}")

    # ✅ Generate PDF Report
    generate_report(findings, reports_dir)
    print(f"[+] PDF report and pie chart saved to {reports_dir}")

if __name__ == "__main__":
    main()
