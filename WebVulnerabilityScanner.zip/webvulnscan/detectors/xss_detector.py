import requests

def test_xss(url, form_details, payloads, session=None):
    results = []
    sess = session or requests

    for payload in payloads:
        data = {}
        for inp in form_details["inputs"]:
            if inp["name"]:
                data[inp["name"]] = payload
        try:
            if form_details["method"] == "post":
                r = sess.post(form_details["action"], data=data, timeout=5)
            else:
                r = sess.get(form_details["action"], params=data, timeout=5)

            if payload in r.text:
                results.append({
                    "url": form_details["action"],
                    "payload": payload,
                    "evidence": r.text[:200]
                })
        except Exception as e:
            print(f"[!] Error testing {url}: {e}")
    return results
