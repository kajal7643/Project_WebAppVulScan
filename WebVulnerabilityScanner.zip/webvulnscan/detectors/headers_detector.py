def test_headers(response):
    """
    Checks missing security headers.
    """
    required_headers = [
        "X-Frame-Options",
        "Content-Security-Policy",
        "X-Content-Type-Options",
        "Strict-Transport-Security"
    ]

    missing = []
    for header in required_headers:
        if header not in response.headers:
            missing.append(header)

    results = []
    for m in missing:
        results.append({
            "url": response.url,
            "payload": "N/A",
            "evidence": f"Missing header: {m}"
        })
    return results
