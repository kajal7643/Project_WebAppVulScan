from bs4 import BeautifulSoup

def test_csrf(url, form_details):
    """
    Detects potential CSRF by checking if a form has hidden CSRF tokens.
    """
    inputs = form_details.get("inputs", [])
    token_fields = ["csrf", "token", "authenticity_token", "_csrf"]
    has_token = any(inp["name"] and any(t in inp["name"].lower() for t in token_fields) for inp in inputs)

    if not has_token:
        return [{
            "url": form_details["action"],
            "payload": "N/A",
            "evidence": "Form has no anti-CSRF token"
        }]
    return []
