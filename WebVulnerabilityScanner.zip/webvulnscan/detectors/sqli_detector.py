import requests
import re

SQL_ERRORS = [
    "you have an error in your sql syntax",
    "warning: mysql",
    "unclosed quotation mark",
    "quoted string not properly terminated",
    "SQLSTATE"
]

def test_sqli(url, form_details, payloads, session=None):
    results = []
    sess = session or requests

    for payload in payloads:
        data = {}
        for inp in form_details["inputs"]:
            if inp["name"]:
                data[inp["name"]] = payload
        try:
            if form_details["method"] == "post":
                r = sess.post(form_details["action"], data=data, timeout=5)
            else:
                r = sess.get(form_details["action"], params=data, timeout=5)

            for err in SQL_ERRORS:
                if re.search(err, r.text, re.IGNORECASE):
                    results.append({
                        "url": form_details["action"],
                        "payload": payload,
                        "evidence": r.text[:200]
                    })
        except Exception as e:
            print(f"[!] Error testing {url}: {e}")
    return results
