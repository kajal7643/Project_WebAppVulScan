# Web Application Vulnerability Scanner

**Author:** Kajal Appasaheb Dabade  
**Year:** 2025

## Project Overview
A Python-based web vulnerability scanner that automates crawling, payload injection, and response analysis to detect common web vulnerabilities (e.g. SQL Injection, Cross-Site Scripting). Includes a lightweight Flask dashboard for running scans and reviewing results.

## Features
- Automated crawling of target web applications to enumerate URLs and input fields.
- Payload injection modules for testing SQLi and XSS vectors.
- Response analysis using regex/pattern matching to identify vulnerable behavior.
- Flask web interface for initiating scans and viewing results.
- Structured logging of findings (severity, evidence, request/response snippets).

## Quick Start (Local)
1. Create and activate a Python virtual environment (recommended):
```bash
python -m venv venv
# macOS / Linux
source venv/bin/activate
# Windows (PowerShell)
venv\Scripts\Activate.ps1
# Windows (cmd)
venv\Scripts\activate.bat
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the application (entrypoint detected in this package):
```bash
python webvulnscan/run.py
```

4. Open your browser at `http://127.0.0.1:5000` (or as indicated in the console).

> If the detected entrypoint above is not correct, replace it with your Flask runner (for example `export FLASK_APP=app.py && flask run` on macOS/Linux).

## Folder Structure (top-level)
```
webvulnscan
```

## Preparing the repository for GitHub (CLI)
From the `webvulnscan_github` directory run:
```bash
git init
git add .
git commit -m "Initial commit: Web Vulnerability Scanner"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/REPO_NAME.git
git push -u origin main
```

## Preparing the repository for GitHub (Web upload)
1. Create a new repository on GitHub (Settings → New repository).  
2. In the repo, click **Add file → Upload files**. Drag and drop the project folder contents (not the zip).  
3. Commit changes with message "Initial project upload".

## Make repository accessible to your manager
- Option A (Public): When creating the repo, choose **Public** and share the repo URL.
- Option B (Private): Add your manager as a collaborator (Repository → Settings → Manage access → Invite collaborator).

## Best practices & Notes
- **Authorization:** Only run scans against targets you own or for which you have explicit permission.
- **Logging:** Do not include sensitive credentials in logs or committed files.
- **Documentation:** Keep `report.pdf` and the short `project_report.md` in the repo root for quick review.
- **License:** This package includes an MIT license (`LICENSE`) — change author/year if needed.

## Contact
If you face any issues while running or uploading the project, contact: Kajal Appasaheb Dabade

---
